package online;
// Домашнее задание 10.12 Немыткина Ксения

public class HomeWork01 {
    public static void main (String[] args) {

   System.out.println(hwOne(2, 2, 2 ,2));
   System.out.println(hwTwo(1, 2));
   hwThree(-5);
   System.out.println(hwFour("Xenia"));
    }
    // 1.Написать метод вычисляющий выражение a*(b+(c/d)) и возвращающий результат с плавающей точкой, где a,b,c,d -
        // целочисленные входные параиетры этого метода
    public static int hwOne (int a, int b, int c, int d) {
        return  a * (b + (c / d));
    }

    // 2. Написать метод, принимающий на вход два целых числа и проверяющий, что их сумма лежит в пределах от 10 до 20
    // (включительно), если да - вернуть в true, в противном случае - в false
    public static boolean hwTwo (int a, int b) {
        return 10 < a + b && a + b < 20;
    }

    // 3. Написать метод, которому в качестве параметра передается целое число, метод должен проверить положительное
    // ли число передали, или отрицательное. Ноль считаем положительным числом. Результат вывести в консоль
    public static void hwThree (int a){

        if (a >= 0) {
            System.out.println("Число " + a + " положительное");
        } else {
            System.out.println("Число " + a + " отрицательное");
        }

    }
    // 4. Написать метод, которому в качестве параметра передается строка, обозначающая имя, метод должен вернуть
    // приветственное сообщение "Привет, переданное_имя!", вывести на консоль

    public static String hwFour (String name) {
        System.out.println("Hello, " + name + "!");
        return name;
    }

    }







